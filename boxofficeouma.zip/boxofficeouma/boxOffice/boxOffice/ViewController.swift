//
//  ViewController.swift
//  boxOffice
//
//  Created by Sinda Arous on 8/2/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

