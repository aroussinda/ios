//
//  ajouterformation.swift
//  success
//
//  Created by Apple Esprit on 28/11/2021.
//

import UIKit

class ajouterformation: UIViewController {
    
    @IBOutlet weak var nomformateur: UITextField!
    @IBOutlet weak var nomformation: UITextField!
    @IBOutlet weak var prix: UITextField!
    @IBOutlet weak var desc: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func termintapped(_ sender: Any) {
        
        if nomformateur.text!.isEmpty || nomformation.text!.isEmpty || prix.text!.isEmpty || desc.text!.isEmpty {
            self.present(Alert.makeAlert(titre: "Avertissement", message: "Champs vide"),animated: true)
            return
        }
        
        let formation = Formation(nomFormateur: nomformateur.text!, nomFormation: nomformation.text!, prix: Float(prix.text!)!, description: desc.text!)
        
        FormationViewModel.sharedInstance.add(formation: formation) { success in
            if success {
                self.present(Alert.makeActionAlert(titre: "Succes", message: "Formation ajouté", action: UIAlertAction(title: "OK", style: .default, handler: { UIAlertAction in
                    self.dismiss(animated: true, completion: nil)
                })),animated: true)
                //self.performSegue(withIdentifier: "seg1000", sender: self)
            } else {
                print("")
            }
        }
        
        func showAlert(title:String, message:String){
            let alert = UIAlertController(title: title, message: message,preferredStyle: .alert)
            let action = UIAlertAction(title:"ok", style: .cancel, handler:nil)
            alert.addAction(action)
            self.present(alert, animated: true, completion: nil)
        }
    }
}
