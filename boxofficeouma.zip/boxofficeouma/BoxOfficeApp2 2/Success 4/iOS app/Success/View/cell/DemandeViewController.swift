//
//  DemandeViewController.swift
//  success
//
//  Created by Apple Esprit on 6/12/2021.
//

import UIKit

class DemandeViewController: UIViewController {
    
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var cvLabel: UILabel!
    @IBOutlet weak var nomdem: UITextField!
    @IBOutlet weak var cv: UITextField!
    @IBOutlet weak var envoyer: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        descriptionLabel.isHidden = true
        cvLabel.isHidden = true
        nomdem.isHidden = true
        cv.isHidden = true
        envoyer.isHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        DemandeViewModel.sharedInstance.check { [self] success, exists, demande in
            if success {
                if exists! {
                    descriptionLabel.isHidden = false
                    if demande?.etat == 1 {
                        descriptionLabel.text = "Demande accepté"
                    } else if demande?.etat == -1 {
                        descriptionLabel.text = "Demande refusé"
                    } else {
                        descriptionLabel.text = "Demande en cours de traitement"
                    }
                } else {
                    descriptionLabel.isHidden = false
                    cvLabel.isHidden = false
                    nomdem.isHidden = false
                    cv.isHidden = false
                    envoyer.isHidden = false
                }
            }
        }
    }
    
    @IBAction func envoyettap(_ sender: Any) {
        if nomdem.text == "" || cv.text == "" {
            self.showAlert(title: "Missing info !", message: "Please make sure to fill all the form and try again")
        }else {
            let demande = Demande(nom: nomdem.text!, cv: cv.text!, etat: 0)
            DemandeViewModel.sharedInstance.add(demande: demande) { sucess in
                if sucess{
                    self.present(Alert.makeSingleActionAlert(titre: "Success", message: "Demande envoyé avec succes", action: UIAlertAction(title: "Ok", style: .default, handler: { UIAlertAction in
                        self.dismiss(animated: true, completion: nil)
                    })),animated: true)
                }
            }
        }
    }
    
    func showAlert(title:String, message:String){
        let alert = UIAlertController(title: title, message: message,preferredStyle: .alert)
        let action = UIAlertAction(title:"ok", style: .cancel, handler:nil)
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
}
