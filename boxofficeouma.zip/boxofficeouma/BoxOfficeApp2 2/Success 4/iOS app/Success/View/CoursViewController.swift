//
//  CoursViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit
import PDFKit
import Alamofire
import SwiftyJSON

class CoursViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var cours : [Cour] = []
    
    var coursname = [String]()
    var coursLien = [String]()
    
    var courTitle : String?
    var pdfviewObject:PDFView = PDFView()
    var pdfDocumntObject:PDFDocument = PDFDocument()
    var totalPageCount = 0
    var dato = ["chapitre1","chapitre2","chapitre3"]
    var chap = ["tablViewController","collectionViewController","Cordata"]
    var ima = ["pdf","pdf","pdf"]
    
    @IBOutlet weak var tableview: UITableView!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cours.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
        let contentView = cell?.contentView
        let nomCour = contentView?.viewWithTag(1) as! UILabel
         
        nomCour.text = cours[indexPath.row].nom
        /*let cours = contentView?.viewWithTag(3) as! UILabel
        let chapt = contentView?.viewWithTag(8) as! UILabel
        chapt.text = chap[indexPath.row]
        cours.text = dato[indexPath.row]
        let imageView = contentView?.viewWithTag(9) as! UIImageView
        imageView.image = UIImage(named: ima[indexPath.row])
        */
        return cell!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
         loadExercises()
        /*tableview.reloadData()
        pdfviewObject = PDFView(frame: self.view.bounds)
        self.view.addSubview(pdfviewObject)
        guard let path = Bundle.main.url(forResource: "courspdf", withExtension: "pdf")
        else
        {
            print("Error in PDF Path")
            return
        }
        
        pdfDocumntObject = PDFDocument(url: path)!
        pdfviewObject.autoScales = true
        pdfviewObject.displayMode = .singlePage
        pdfviewObject.displayDirection = .horizontal
        pdfviewObject.usePageViewController(true)
        totalPageCount = 0
        
        if let total = pdfviewObject.document?.pageCount {
            totalPageCount = total
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(countPages), name: Notification.Name.PDFViewPageChanged, object: nil)
        countPages()*/
    }
    
    override func viewDidAppear(_ animated: Bool) {
        CourViewModel.sharedInstance.getAll { [self] success, coursFromRep in
            if success {
                cours = coursFromRep!
                self.tableview.reloadData()
            }else {
                self.present(Alert.makeAlert(titre: "Error", message: "Could not load formations "),animated: true)
            }
        }
    }
    
    @objc func countPages()
    {
        let currentPageNumber = pdfDocumntObject.index(for: pdfviewObject.currentPage!)+1
        let totalPage = "\(currentPageNumber)/\(totalPageCount)"
        title = "PDF Viewer \(totalPage)"
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "coursDetail", sender: indexPath)
    }
    
    
    
    func loadExercises()  {
      
        AF.request(HOST + "cour", method: .get).responseJSON{
            response in
            switch response.result{
            
                
            case .success:
               //self.removeSpinner()
               // print(response)
                let myresult = try? JSON(data: response.data!)
                // print(myresult)
                self.coursname.removeAll()
                self.coursLien.removeAll()
              
                
                
                for i in myresult!["cours"].arrayValue {
                    //print(i)
                   
                    let nom = i["nom"].stringValue
                  
                    let description = i["description"].stringValue
                    self.coursname.append(nom)
                    self.coursLien.append(description)
                   // print(image)
                }
               
                break
            case .failure:
                
               

                print("CHECK INTERNET CONNECTION!!!!!!!!!!")
                print(response.error!)
                
                break
            }
        }
        
       
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "coursDetail" {
            let indexPath = sender as! IndexPath
            let destination = segue.destination as! listecourscienceViewController
            destination.nomcoursString = coursname[indexPath.row]
            destination.descriptionCoursString = coursLien[indexPath.row]
         
        }
    }
    
    
    
}
