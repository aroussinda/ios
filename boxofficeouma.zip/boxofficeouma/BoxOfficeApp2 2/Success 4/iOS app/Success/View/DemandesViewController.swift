//
//  DemandesViewController.swift
//  success
//
//  Created by Apple Mac on 24/12/2021.
//

import Foundation
import UIKit

class DemandesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var demandes : [Demande] = []
    
    @IBOutlet weak var tableview: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return demandes.count
    }
    
    override func viewDidAppear(_ animated: Bool) {
        initialize()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
        let contentView = cell?.contentView
        
        let demandeLabel = contentView?.viewWithTag(1) as! UILabel
        let userNameLabel = contentView?.viewWithTag(2) as! UILabel
        let cvLabel = contentView?.viewWithTag(3) as! UILabel
        let btnAccepter = contentView?.viewWithTag(4) as! UIButton
        let btnRefuser = contentView?.viewWithTag(5) as! UIButton
        let etatLabel = contentView?.viewWithTag(6) as! UILabel

        var demande = demandes[indexPath.row]
        
        if demande.etat == 1 {
            btnAccepter.isHidden = true
            btnRefuser.isHidden = true
            etatLabel.isHidden = false
            etatLabel.text = "Demande accepté"
        } else if demande.etat == -1 {
            btnAccepter.isHidden = true
            btnRefuser.isHidden = true
            etatLabel.isHidden = false
            etatLabel.text = "Demande refusé"
        } else {
            btnAccepter.isHidden = false
            btnRefuser.isHidden = false
            etatLabel.isHidden = true
        }
        
        demandeLabel.text = "Description : " + demande.nom
        userNameLabel.text = "User : " + demande.user!.nom
        cvLabel.text = "CV : " + demande.cv
        
        btnAccepter.addAction(UIAction(handler: { uiAction in
            demande.etat = 1
            DemandeViewModel.sharedInstance.edit(demande: demande) { success in
                if success {
                    self.initialize()
                }
            }
        }),for: .touchUpInside)
        
        btnRefuser.addAction(UIAction(handler: { uiAction in
            demande.etat = -1
            DemandeViewModel.sharedInstance.edit(demande: demande) { success in
                if success {
                    self.initialize()
                }
            }
        }),for: .touchUpInside)
        
        return cell!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func initialize() {
        DemandeViewModel.sharedInstance.getAll { [self] success, demandesFromRep in
            if success {
                demandes = demandesFromRep!
                
                tableview.reloadData()
            }
        }
    }
    
}

