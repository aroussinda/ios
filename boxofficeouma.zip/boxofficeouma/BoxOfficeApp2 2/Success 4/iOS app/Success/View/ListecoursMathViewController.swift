//
//  ListecoursMathViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit
import PDFKit

class ListecoursMathViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var courTitle : String?
    var pdfviewObject:PDFView = PDFView()
    var pdfDocumntObject:PDFDocument = PDFDocument()
    var totalPageCount = 0
    
    var math = ["Fonction linéaire","probabilite","algebre","analyse"]
    var iman = ["pdf","pdf","pdf","pdf"]

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return math.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell2")
        let contentView = cell?.contentView
        let Label = contentView?.viewWithTag(11) as! UILabel
        let imageView = contentView?.viewWithTag(10) as! UIImageView
        Label.text = math[indexPath.row]
        imageView.image = UIImage(named: iman[indexPath.row])
    return cell!
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "seg15", sender: self)
    }
    
    //func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
      //  let cour =  math[indexPath.row]
        //performSegue(withIdentifier: "seg15", sender: cour)
   // }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        pdfviewObject = PDFView(frame: self.view.bounds)
        self.view.addSubview(pdfviewObject)
        guard let path = Bundle.main.url(forResource: "courspdf", withExtension: "pdf")
        else
        {
         print("Error in PDF Path")
            return
        }
        pdfDocumntObject = PDFDocument(url: path)!
        pdfviewObject.autoScales = true
        pdfviewObject.displayMode = .singlePage
        pdfviewObject.displayDirection = .horizontal
        pdfviewObject.usePageViewController(true)
        totalPageCount = 0
        if let total = pdfviewObject.document?.pageCount {
            totalPageCount = total
        }
        NotificationCenter.default.addObserver(self, selector: #selector(countPages), name: Notification.Name.PDFViewPageChanged, object: nil)
        countPages()
    }
    
    @objc func countPages()
    {
        let currentPageNumber = pdfDocumntObject.index(for: pdfviewObject.currentPage!)+1
        let totalPage = "\(currentPageNumber)/\(totalPageCount)"
        title = "PDF Viewer \(totalPage)"
    }

}
