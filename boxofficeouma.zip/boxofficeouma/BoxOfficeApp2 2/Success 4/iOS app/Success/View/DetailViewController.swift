//
//  DetailViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit
import Braintree
import LocalAuthentication

class DetailViewController: UIViewController {
    
    var braintreeClient: BTAPIClient!
    var formation : Formation?
    
    @IBOutlet weak var nomFormation: UILabel!
    @IBOutlet weak var nomFormateur: UILabel!
    @IBOutlet weak var prixFormation: UILabel!
    @IBOutlet weak var descriptionFormation: UILabel!
    
    @IBOutlet weak var textes: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        initialize()
        
        braintreeClient = BTAPIClient(authorization: "sandbox_x6d2jcjs_23v46x9jx3wjsq5p")
    }
    
    func initialize() {
        nomFormation.text = "Formation : " + formation!.nomFormation
        nomFormateur.text = "Formateur : " + formation!.nomFormateur
        prixFormation.text = "Prix : " + String((formation?.prix)!)
        descriptionFormation.text = "Description : " + formation!.description
        textes.isEditable = false
        textes.dataDetectorTypes = .link
        textes.text =  formation!.description
    }
    
    
    @IBAction func clikBtnPay(_ sender: Any) {
        
        let localString = "Biometric Authentication"
        let context = LAContext()
           var error: NSError?

           if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
               let reason = "Identify yourself!"

               context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
                   [weak self] success, authenticationError in

                   DispatchQueue.main.async {
                       if success {
                           let payPalDriver = BTPayPalDriver(apiClient: self!.braintreeClient)
                           payPalDriver.viewControllerPresentingDelegate = self
                           payPalDriver.appSwitchDelegate = self // Optional
                           // Specify the transaction amount here. "2.32" is used in this example.
                           let request = BTPayPalRequest(amount: "2.32")
                           request.currencyCode = "USD" // Optional; see BTPayPalRequest.h for more options
                           
                           payPalDriver.requestOneTimePayment(request) { (tokenizedPayPalAccount, error) in
                               if let tokenizedPayPalAccount = tokenizedPayPalAccount {
                                   print("Got a nonce: \(tokenizedPayPalAccount.nonce)")
                                   
                                   // Access additional information
                                   let email = tokenizedPayPalAccount.email
                                   let firstName = tokenizedPayPalAccount.firstName
                                   let lastName = tokenizedPayPalAccount.lastName
                                   let phone = tokenizedPayPalAccount.phone
                                   
                                   // See BTPostalAddress.h for details
                                   let billingAddress = tokenizedPayPalAccount.billingAddress
                                   let shippingAddress = tokenizedPayPalAccount.shippingAddress
                               } else if let error = error {
                                   // Handle error here...
                               } else {
                                   // Buyer canceled payment approval
                               }
                           }
                       } else {
                           // error
                       }
                   }
               }
           } else {
               // no biometry
    }
        
        
        
        
        
        
        
        
        

    }
}

extension DetailViewController : BTViewControllerPresentingDelegate{
    
    func paymentDriver(_ driver: Any, requestsPresentationOf viewController: UIViewController) {
        
    }
    
    func paymentDriver(_ driver: Any, requestsDismissalOf viewController: UIViewController) {
        
    }
    
}

extension DetailViewController : BTAppSwitchDelegate{
    
    func appSwitcherWillProcessPaymentInfo(_ appSwitcher: Any) {
        
    }
    
    func appSwitcherWillPerformAppSwitch(_ appSwitcher: Any) {
        
    }
    
    func appSwitcher(_ appSwitcher: Any, didPerformSwitchTo target: BTAppSwitchTarget) {
        
    }
}


