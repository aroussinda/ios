//
//  listecourscienceViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit
import PDFKit

class listecourscienceViewController: UIViewController {
    
    
    @IBOutlet weak var textView: UITextView!
   
    @IBOutlet weak var nameCourse: UILabel!
    
    var nomcoursString: String?
    var descriptionCoursString: String?
    
    override func viewDidLoad() {
        nameCourse.text = nomcoursString
        
        
        textView.text = descriptionCoursString
        textView.isEditable = false
        textView.dataDetectorTypes = .link
        super.viewDidLoad()
       
    }
    
  

}
