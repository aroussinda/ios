//
//  ListecoursInfoViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class ListecoursInfoViewController: UIViewController{
    
    
    
    
    var nomcoursString: String?
    var descriptionCoursString: String?
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
