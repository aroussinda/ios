//
//  Update.swift
//  success
//
//  Created by iMac on 11/12/2021.
//

import UIKit

class Update: UIViewController {
    
    @IBOutlet weak var names: UITextField!
    @IBOutlet weak var usernames: UITextField!
    @IBOutlet weak var eemail: UITextField!
    @IBOutlet weak var ppass: UITextField!
    @IBOutlet weak var cconfirme: UITextField!
    
    var id = UserDefaults.standard.string(forKey: "id")!
    let token = UserDefaults.standard.string(forKey: "token")!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(id)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func modifier(_ sender: Any) {
        print("this is the token:",id)
        
        if names.text == "" || usernames.text == "" || eemail.text == ""  || ppass.text == ""   || cconfirme.text == "" {
            
            self.showAlert(title: "Missing info !", message: "Please make sure to fill all the form and try again")
            
        }else{
            
            
            let user = User(_id: id, nom: names.text!, username: usernames.text!, email: eemail.text!, password: ppass.text!, role: "User")
            UserViewModel.sharedInstance.updateProfile(user: user) { sucess in
                if sucess {
                    self.showAlert(title: "info !", message: "user edited")
                } else {
                }
            }
        }
        
    }
    
    func showAlert(title:String, message:String){
        
        let alert = UIAlertController(title: title, message: message,preferredStyle: .alert)
        
        let action = UIAlertAction(title:"ok", style: .cancel, handler:nil)
        
        alert.addAction(action)
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    @IBAction func supprimation(_ sender: Any) {
        print("this is the token:",id)
        if names.text == "" || usernames.text == "" || eemail.text == ""  || ppass.text == ""   || cconfirme.text == "" {
            
            self.showAlert(title: "Missing info !", message: "Please make sure to fill all the form and try again")
            
        } else {
            let user = User(_id: id, nom: names.text!, username: usernames.text!, email: eemail.text!, password: ppass.text!, role: "User")
            UserViewModel.sharedInstance.updateProfile(user: user) { sucess in
                if sucess{
                    self.showAlert(title: "info !", message: "user deleted")
                }else{
                    
                }
            }
        }
        
        func showAlert(title:String, message:String){
            
            let alert = UIAlertController(title: title, message: message,preferredStyle: .alert)
            
            let action = UIAlertAction(title:"ok", style: .cancel, handler:nil)
            
            alert.addAction(action)
            
            self.present(alert, animated: true, completion: nil)
        }
    }
}
