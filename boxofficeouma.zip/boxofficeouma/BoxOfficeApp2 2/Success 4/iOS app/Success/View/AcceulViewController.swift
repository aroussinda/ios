//
//  AcceulViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class AcceulViewController: UIViewController {
    
    @IBOutlet weak var demandeEtreFormateurButton: UIButton!
    @IBOutlet weak var consulterButton: UIButton!
    @IBOutlet weak var AjouterButton: UIButton!
    @IBOutlet weak var consulterFButton: UIButton!
    @IBOutlet weak var ajouterfButton: UIButton!
    @IBOutlet weak var demande: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if reachability.connection == .unavailable {
            //print("jawek mesh behy")
            showSpinner()
            self.present(Alert.makeAlert(titre: "warning", message: "test"), animated: true)
        }else
        
      {  if UserDefaults.standard.string(forKey: "role") != nil {
            if UserDefaults.standard.string(forKey: "role")! == "Admin" {
                demandeEtreFormateurButton.setTitle("Demandes", for: .normal)
            }
        }}
    }

    @IBAction func consulterButton(_ sender: Any) {
  
    }
    @IBAction func AjouterButton(_ sender: Any) {
       
    }
    @IBAction func consulterFButton(_ sender: Any) {
        
    }
    @IBAction func ajouterfButton(_ sender: Any) {
    
    }
    
    @IBAction func demandetapped(_ sender: Any) {
        if UserDefaults.standard.string(forKey: "role") != nil {
            if UserDefaults.standard.string(forKey: "role")! == "Admin" {
                self.performSegue(withIdentifier: "voirDemandeFormationSegue", sender: nil)
            } else {
                self.performSegue(withIdentifier: "demandeFormationSegue", sender: nil)
            }
        }
    }
    
    
    @IBOutlet weak var para2: UILabel!
    @IBOutlet weak var para1: UILabel!
    @IBOutlet weak var switchthemeBtn: UIButton!
    
    @IBOutlet weak var ofKnowledge: UILabel!
    
    @IBAction func modeSwitcher(_ sender: Any) {
        let window = UIApplication.shared.keyWindow
            if #available(iOS 13.0, *) {
                if window?.overrideUserInterfaceStyle == .dark {
                    switchthemeBtn.tintColor = .black
                    switchthemeBtn.setTitle("Light mode", for: .normal)
                    window?.overrideUserInterfaceStyle = .light
                    ofKnowledge.textColor = .black
                    para1.textColor = .darkGray
                    para2.textColor = .darkGray
                   
                } else {
                    switchthemeBtn.tintColor = .white
                    window?.overrideUserInterfaceStyle = .dark
                    switchthemeBtn.setTitle("Dark mode", for: .normal)
                    ofKnowledge.textColor = .white
                    para1.textColor = .white
                    para2.textColor = .white
                }
            }
    }
    
    
    
    func showAlert(title:String, message:String){
                  let alert = UIAlertController(title: title, message: message,preferredStyle: .alert)
                  let action = UIAlertAction(title:"ok", style: .cancel, handler:nil)
                  alert.addAction(action)
                  self.present(alert, animated: true, completion: nil)

    }
}
