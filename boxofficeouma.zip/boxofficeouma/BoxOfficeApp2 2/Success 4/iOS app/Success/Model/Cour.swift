//
//  Cours.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation

struct Cour : Encodable {
    
    internal init(_id: String? = nil, nom: String, categorie: Categorie, pdf: String, description: String) {
        self._id = _id
        self.nom = nom
        self.categorie = categorie
        self.pdf = pdf
        self.description = description
    }
    
    var _id: String?
    var nom: String
    var categorie : Categorie
    var pdf : String
    var description : String
    
}
