import Foundation

let HOST = "http://localhost:3000/api/"
let HOST_IMAGES = "http://localhost:3000/img/"

let ROUNDED_RADIUS = 20.0
