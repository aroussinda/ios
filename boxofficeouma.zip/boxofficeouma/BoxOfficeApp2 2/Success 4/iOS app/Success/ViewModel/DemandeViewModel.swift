//
//  DemandeViewModel.swift
//  success
//
//  Created by Apple Esprit on 28/11/2021.
//

import SwiftyJSON
import Alamofire

public class DemandeViewModel: ObservableObject{
    
    static let sharedInstance = DemandeViewModel()
    
    func getAll(completed: @escaping (Bool, [Demande]?) -> Void) {
        AF.request(HOST + "demande",
                   method: .get)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    var demandes : [Demande] = []
                    for demande in JSON(response.data!)["demandes"] {
                        demandes.append(DemandeViewModel.sharedInstance.makeDemande(jsonItem: demande.1))
                    }
                    
                    completed(true, demandes)
                case let .failure(error):
                    print(error)
                    completed(false, nil)
                }
            }
    }
    
    func check(completed: @escaping (Bool, Bool?, Demande?) -> Void) {
        AF.request(HOST + "demande/check",
                   method: .post,
                   parameters: [
                    "user": UserDefaults.standard.string(forKey: "id")!
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { [self] response in
                switch response.result {
                case .success:
                    
                    if JSON(response.data!)["exist"].boolValue {
                        completed(true, true, makeDemande(jsonItem: JSON(response.data!)["demande"]))
                    } else {
                        completed(true, false, nil)
                    }
                    
                case let .failure(error):
                    print(error)
                    completed(false, nil, nil)
                }
            }
    }
    
    func add(demande: Demande, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "demande",
                   method: .post,
                   parameters: [
                    "nom": demande.nom,
                    "cv": demande.cv,
                    "user" : UserDefaults.standard.string(forKey: "id")!
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func edit(demande: Demande, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "demande",
                   method: .put,
                   parameters: [
                    "_id": demande._id!,
                    "etat": demande.etat
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func delete(demande: Demande, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "demande",
                   method: .delete,
                   parameters: [ "_id": demande._id! ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func makeDemande(jsonItem: JSON) -> Demande {
        Demande(
            _id: jsonItem["_id"].stringValue,
            nom: jsonItem["nom"].stringValue,
            cv: jsonItem["cv"].stringValue,
            etat: jsonItem["etat"].intValue,
            user: UserViewModel.sharedInstance.makeUser(jsonItem: jsonItem["user"])
        )
    }
}

