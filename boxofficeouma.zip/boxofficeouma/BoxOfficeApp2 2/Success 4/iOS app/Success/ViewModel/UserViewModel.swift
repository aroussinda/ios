//
//  Userservice.swift
//  success
//
//  Created by Apple Esprit on 2/12/2021.
//

import Foundation
import SwiftyJSON
import Alamofire
import UIKit.UIImage

public class UserViewModel: ObservableObject{
    
    static let sharedInstance = UserViewModel()
    
    func register(user: User, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "user/register",
                   method: .post,
                   parameters: [
                    "nom": user.nom,
                    "username": user.username,
                    "email": user.email,
                    "password": user.password!
                   ])
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func login(user: User, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "user/login",
                   method: .post,
                   parameters: [
                    "email": user.email,
                    "password": user.password!
                   ])
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { [self] response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    
                    let user = makeUser(jsonItem: JSON(response.data!)["user"])
                    
                    UserDefaults.standard.setValue(user._id, forKey: "id")
                    UserDefaults.standard.setValue(user.role, forKey: "role")
                    UserDefaults.standard.setValue(JSON(response.data!)["token"].stringValue, forKey: "token")
                    
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func updateProfile(user: User, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "user/updateProfil",
                   method: .put,
                   parameters: [
                    "_id": UserDefaults.standard.string(forKey: "id")!,
                    "nom": user.nom,
                    "username": user.username,
                    "email": user.email,
                    "password": user.password!,
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func makeUser(jsonItem: JSON) -> User {
        User(
            _id: jsonItem["_id"].stringValue,
            nom: jsonItem["nom"].stringValue,
            username: jsonItem["username"].stringValue,
            email: jsonItem["email"].stringValue,
            password: jsonItem["password"].stringValue,
            role: jsonItem["role"].stringValue
        )
    }
}
