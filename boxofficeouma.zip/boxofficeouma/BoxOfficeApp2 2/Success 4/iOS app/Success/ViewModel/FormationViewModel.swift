//
//  FormationViewModel.swift
//  success
//
//  Created by Apple Esprit on 28/11/2021.
//


import SwiftyJSON
import Alamofire
import UIKit.UIImage

public class FormationViewModel: ObservableObject{
    
    static let sharedInstance = FormationViewModel()
    
    func getAll(completed: @escaping (Bool, [Formation]?) -> Void) {
        AF.request(HOST + "formation",
                   method: .get)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    var formations : [Formation] = []
                    for formation in JSON(response.data!)["formations"] {
                        formations.append(FormationViewModel.sharedInstance.makeFormation(jsonItem: formation.1))
                    }
                    
                    completed(true, formations)
                case let .failure(error):
                    print(error)
                    completed(false, nil)
                }
            }
    }
    
    func add(formation: Formation, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "formation",
                   method: .post,
                   parameters: [
                    "nomFormateur": formation.nomFormateur,
                    "nomFormation": formation.nomFormation,
                    "prix": formation.prix,
                    "description": formation.description
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func edit(formation: Formation, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "formation",
                   method: .put,
                   parameters: [
                    "_id": formation._id!,
                    "nomFormateur": formation.nomFormateur,
                    "nomFormation": formation.nomFormation,
                    "prix": formation.prix,
                    "description": formation.description
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func delete(formation: Formation, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "formation",
                   method: .delete,
                   parameters: [ "_id": formation._id! ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func makeFormation(jsonItem: JSON) -> Formation {
        Formation(
            nomFormateur: jsonItem["nomFormateur"].stringValue,
            nomFormation: jsonItem["nomFormation"].stringValue,
            prix: jsonItem["prix"].floatValue,
            description: jsonItem["description"].stringValue
        )
    }
}

